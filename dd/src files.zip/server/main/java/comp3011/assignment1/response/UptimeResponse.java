package comp3011.assignment1.response;
import java.time.Instant;
public class UptimeResponse {
	private final Instant utcServerStart;
	private final Instant utcNow;
	private final double serverUptimeSeconds;
	
	public UptimeResponse(Instant utcServerStart, Instant utcNow, double serverUptimeSeconds) {
        this.utcServerStart = utcServerStart;
        this.utcNow = utcNow;
        this.serverUptimeSeconds = serverUptimeSeconds;
    }

    public Instant getUtcServerStart() {
        return utcServerStart;
    }

    public Instant getUtcNow() {
        return utcNow;
    }

    public double getServerUptimeSeconds() {
        return serverUptimeSeconds;
    }
    
    
}
